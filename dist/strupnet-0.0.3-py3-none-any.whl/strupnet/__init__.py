from .snn import SympNet
from .hnn import HamiltonianNet
from .nn.scalar import ScalarNet
