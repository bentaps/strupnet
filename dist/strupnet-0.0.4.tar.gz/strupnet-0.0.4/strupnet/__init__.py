from .snn import SympNet
from .vnn import VolNet
from .nn.scalar import ScalarNet
